# GitHub & Render Deployment Guide

This guide will walk you through publishing the Portfolio Builder to GitHub and deploying it on Render.

## Step 1: Create a GitHub Repository

### Option A: Using GitHub Web Interface

1. Go to https://github.com/new
2. Enter repository name: `portfolio-builder`
3. Add description: "A full-stack portfolio builder application for pharmacists"
4. Choose **Public** (so Render can access it)
5. Click "Create repository"
6. **Do NOT initialize with README** (we already have one)

### Option B: Using GitHub CLI

```bash
gh repo create portfolio-builder --public --source=. --remote=origin --push
```

## Step 2: Push Code to GitHub

After creating the repository, you'll see instructions. Follow these commands:

```bash
cd /home/ubuntu/portfolio-builder

# Add GitHub as remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/portfolio-builder.git

# Rename branch to main (GitHub's default)
git branch -M main

# Push code to GitHub
git push -u origin main
```

### Verify Push Success

Visit: `https://github.com/YOUR_USERNAME/portfolio-builder`

You should see all your files there!

## Step 3: Deploy on Render

### 3.1 Create Render Account

1. Go to https://render.com
2. Click "Get Started"
3. Sign up with GitHub (this is easiest)
4. Authorize Render to access your GitHub account

### 3.2 Create Web Service

1. Click the **"New +"** button (top right)
2. Select **"Web Service"**
3. Click **"Connect a repository"**
4. Find and select `portfolio-builder`
5. Click "Connect"

### 3.3 Configure Build Settings

Fill in the following details:

| Field | Value |
|-------|-------|
| **Name** | `portfolio-builder` |
| **Environment** | `Node` |
| **Build Command** | `cd backend && npm install && npm run build` |
| **Start Command** | `cd backend && npm start` |
| **Plan** | `Free` |

### 3.4 Add Environment Variables

Click on **"Environment"** section and add these variables:

```
PORT=8080
NODE_ENV=production
DATABASE_URL=file:./dev.db
JWT_SECRET=your-super-secret-key-change-this-12345
CORS_ORIGIN=https://YOUR_RENDER_DOMAIN.onrender.com
PUBLIC_BASE_URL=https://YOUR_RENDER_DOMAIN.onrender.com
UPLOAD_DIR=./uploads
```

**Important**: Replace `YOUR_RENDER_DOMAIN` with the actual domain Render assigns (you'll see it after deployment starts).

**Security Note**: Generate a strong JWT_SECRET. You can use:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 3.5 Deploy

1. Click **"Create Web Service"**
2. Render will start building and deploying
3. Wait for the deployment to complete (usually 2-5 minutes)
4. Once complete, you'll see a green checkmark and a URL like: `https://portfolio-builder-xxxx.onrender.com`

### 3.6 Update Environment Variables with Actual Domain

After deployment completes:

1. Go to your Render dashboard
2. Click on the `portfolio-builder` service
3. Go to **Settings** → **Environment**
4. Update these variables with your actual Render domain:
   - `CORS_ORIGIN=https://portfolio-builder-xxxx.onrender.com`
   - `PUBLIC_BASE_URL=https://portfolio-builder-xxxx.onrender.com`
5. Click "Save Changes"
6. Render will automatically redeploy with the new variables

## Step 4: Test Your Deployment

1. Open your Render URL: `https://portfolio-builder-xxxx.onrender.com`
2. You should see the Portfolio Builder login page
3. Register a new account
4. Create a portfolio
5. View your public profile

## Troubleshooting

### Build Fails

**Error**: `npm: command not found`
- **Solution**: Ensure Node.js is selected in Environment

**Error**: `Cannot find module`
- **Solution**: Check that all dependencies are in `backend/package.json`
- **Fix**: Run `npm install` locally and commit `package-lock.json`

### App Crashes After Deploy

**Check Logs**:
1. Go to Render dashboard
2. Click on your service
3. Click "Logs" tab
4. Look for error messages

**Common Issues**:
- Missing environment variables → Add them in Settings
- Database connection error → Check DATABASE_URL format
- Port already in use → Render handles this automatically

### CORS Errors

**Error**: "Access to XMLHttpRequest blocked by CORS policy"
- **Solution**: Update `CORS_ORIGIN` environment variable to match your Render domain
- **Redeploy**: After updating, Render will automatically redeploy

### Database Persistence

**Important**: SQLite databases are lost when the container restarts!

**For Production**, upgrade to PostgreSQL:

1. Go to Render dashboard
2. Click "New +" → "PostgreSQL"
3. Create a free PostgreSQL database
4. Copy the connection string
5. Update your `portfolio-builder` service:
   - Go to Settings → Environment
   - Change `DATABASE_PROVIDER` to `postgresql`
   - Set `DATABASE_URL` to your PostgreSQL connection string
6. Update `backend/prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
7. Commit and push to GitHub
8. Render will auto-redeploy

## Monitoring Your Deployment

### View Logs
1. Go to Render dashboard
2. Click on your service
3. Click "Logs" tab
4. See real-time logs

### Check Health
Visit: `https://portfolio-builder-xxxx.onrender.com/health`

You should see: `{"ok":true}`

### Monitor Performance
Render provides basic metrics in the dashboard:
- CPU usage
- Memory usage
- Request count
- Response time

## Making Updates

To update your application:

1. Make changes locally
2. Commit to git: `git commit -am "Your message"`
3. Push to GitHub: `git push origin main`
4. Render automatically detects the push and redeploys!

## Custom Domain (Optional)

To use a custom domain like `portfolio.yoursite.com`:

1. Go to Render dashboard
2. Click on your service
3. Go to Settings → Custom Domain
4. Enter your domain
5. Follow DNS instructions from your domain provider

## Next Steps

1. **Upgrade Database**: Switch to PostgreSQL for data persistence
2. **Add Custom Domain**: Set up your own domain name
3. **Enable HTTPS**: Render does this automatically
4. **Monitor Performance**: Set up error tracking (Sentry, etc.)
5. **Add Features**: Implement premium upgrades, email notifications, etc.

## Support

- **Render Docs**: https://render.com/docs
- **Prisma Docs**: https://www.prisma.io/docs
- **Express Docs**: https://expressjs.com

---

**You're all set!** Your Portfolio Builder is now live on the internet! 🚀
